from subprocess import call as sh
import os

def run(run_function):
	run_function('target','run_exploit')

def run_exploit():
    sh(['ls','/home'])
    ret = sh(['/home/a.out'])
    if ret==0:
        return 2
    else:
        return 0
