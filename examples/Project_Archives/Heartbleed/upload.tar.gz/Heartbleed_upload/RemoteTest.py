#!/usr/bin/python2.7
from xshop import test

T = test.TestCase({},target='remote:52.91.248.20')
T.run()
