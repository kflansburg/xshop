#!/bin/bash
cmp -i 8 test.tgz ../origin/test.tgz
