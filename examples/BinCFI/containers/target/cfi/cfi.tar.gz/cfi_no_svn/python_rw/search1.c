#include <stdio.h>

short old_addr;
short i;

void main(){


}

void search1(){


}
