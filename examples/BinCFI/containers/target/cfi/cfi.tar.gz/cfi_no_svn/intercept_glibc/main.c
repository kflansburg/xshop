#include <stdio.h>
void main(){
	char *ptr = (char *)malloc(32);
	printf("hello, world!\n");

}
